package com.cg.banking.controller;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.banking.bean.AccountDetails;
import com.cg.banking.bean.TransactionDetails;
import com.cg.banking.service.IBankService;

@Controller 
public class BankController
{
	@Autowired
	IBankService bSer;

	TransactionDetails tDet;

	@RequestMapping(value="/custName",method = RequestMethod.POST) 
	public ModelAndView custName(@RequestParam("customerName") String cName){  

		
		List<AccountDetails> conL=bSer.selectAccounts(cName);
		return new ModelAndView("AccountInfo","conL",conL);                           //accounts list along with request forwarded 

	}  
	@RequestMapping(value="/debit")
	public ModelAndView debitInput(@RequestParam("accNo") String accNo)
	{  
		//System.out.println("Hello"+accNo); 
		return new ModelAndView("DebitAmount","accNo",accNo);
	}
	@RequestMapping(value="/fromDebit",method = RequestMethod.POST)
	public String insert(@RequestParam("accNo") String accNo,@RequestParam("amount")String amount,Model m)
	{
		tDet=new TransactionDetails();
		tDet.setAccountNumber(accNo);
		tDet.setTransactionAmount(Double.parseDouble(amount));
		tDet.setTransactionDate(java.sql.Date.valueOf(LocalDate.now()));
		tDet.setTransactionDescp("Atm Debit");
		int a=bSer.insertTransacDetails(tDet);           //insert transaction details into table in datasource
		m.addAttribute("tDet",tDet);
		return("TransactionSuccess");                     //forward to Transaction Success page

	}

}



































