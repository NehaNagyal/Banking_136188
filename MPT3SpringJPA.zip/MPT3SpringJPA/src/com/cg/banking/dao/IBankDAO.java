package com.cg.banking.dao;

import java.util.List;

import com.cg.banking.bean.AccountDetails;
import com.cg.banking.bean.TransactionDetails;

public interface IBankDAO 
{
	public List<AccountDetails> selectAccounts(String cName) ;
	public int insertTransacDetails(TransactionDetails tDet) ;
}
