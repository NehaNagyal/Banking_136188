package com.cg.banking.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.banking.bean.AccountDetails;
import com.cg.banking.bean.TransactionDetails;
import com.cg.banking.dao.IBankDAO;

@Service

public class BankService implements IBankService
{
	@Autowired
	IBankDAO bDAO;
	
	public List<AccountDetails> selectAccounts(String cName) 
	{
		return bDAO.selectAccounts(cName);
	}
	public int insertTransacDetails(TransactionDetails tDet)
	{
		return bDAO.insertTransacDetails(tDet);
	}
}
