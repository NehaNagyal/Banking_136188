package com.cg.banking.service;

import java.util.List;

import com.cg.banking.bean.AccountDetails;
import com.cg.banking.bean.TransactionDetails;

public interface IBankService 
{
	public List<AccountDetails> selectAccounts(String cName);
	public int insertTransacDetails(TransactionDetails tDet);
}
