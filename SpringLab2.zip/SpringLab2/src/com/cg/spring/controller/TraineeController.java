package com.cg.spring.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.spring.entities.Trainee;
import com.cg.spring.service.ITraineeService;
import com.cg.spring.service.TraineeServiceImpl;

@Controller
public class TraineeController {
	static int i=0;
	static int j=0;
	static int k=0;
	
	ITraineeService traineeService=new TraineeServiceImpl();

	@RequestMapping(value="/showForm.obj")
	public String showForm()
	{
		return "login";
	}
	
	@RequestMapping(value="/checkLogin.obj")
	public String checkLogin(@RequestParam("username") String userName, @RequestParam("password") String password,Model model)
	{
		if(userName.equals("Akash") && password.equals("akash"))
		{
		return "tmsmenu";
		}
		else
			return "error";
	}
	
	@RequestMapping(value="/addTraineeForm.obj")
	public String addTraineeForm(Model model)
	{
		model.addAttribute("trainee", new Trainee());
		return "addTraineeForm";
	}
	
	@RequestMapping(value="/addTrainee.obj",method=RequestMethod.POST)
	public String addTrainee(@ModelAttribute("trainee") Trainee trainee,Model model)
	{
		model.addAttribute("trainee",trainee);
	
		traineeService.addTrainee(trainee);
		//List<Trainee> tList=traineeService.getAllTrainee();
		return "success";
		
	}
	
	@RequestMapping(value="/deleteTraineeForm.obj")
	public String deleteTraineeForm(Model model)
	{
		
		//model.addAttribute("trainee", new Trainee());
		Trainee temp=null;
		i++;
		if(i==2)
		{
			temp=new Trainee();
		temp.setTid(10);
		temp.setTraineeDomain("asdasd");
		temp.setTraineeLocation("dsd");
		temp.setTraineeName("dasd");
		}
		
		model.addAttribute("num",i);
		model.addAttribute("trainee",temp);
		
		return "deleteTraineeForm";
	}
	
	@RequestMapping(value="/getDeleteTrainee.obj")
	public String getDeleteTrainee(Model model,@RequestParam("tid") int tid)
	{
		model.addAttribute("tid",tid);
		return "redirect:/deleteTraineeForm.obj";
		
	}
	
	@RequestMapping(value="/deleteTrainee.obj")
	public String deleteTrainee(Model model,@RequestParam("tid") int tid)
	{
		model.addAttribute("tid",tid);
		//model.addAttribute("trainee",trainee);
		return "delsuccess";
		
	}
	
	
	@RequestMapping(value="/modifyTraineeForm")
	public String modifyTraineeForm(Model model)
	{
		
		//model.addAttribute("trainee", new Trainee());
		Trainee temp2=null;
	    j++;
		if(j==2)
		{
			temp2=new Trainee();
		temp2.setTid(10);
		temp2.setTraineeDomain("asdasd");
		temp2.setTraineeLocation("dsd");
		temp2.setTraineeName("dasd");
		}
		model.addAttribute("num",i);
		model.addAttribute("trainee",temp2);
		return "modifyTraineeForm";
	}
	
	@RequestMapping(value="/getModifyTrainee")
	public String getModifyTrainee(Model model,@RequestParam("tid") int tid)
	{
		
		model.addAttribute("tid",tid);
		return "redirect:/modifyTraineeForm.obj";
		
	}
	
	@RequestMapping(value="/modifyTrainee")
	public String deleteTrainee(Model model,@ModelAttribute(value="trainee") Trainee trainee)
	{
		//model.addAttribute("tid",tid);
		model.addAttribute("trainee",trainee);
		return "modsuccess";
		
	}
	
	@RequestMapping(value="/retrieveTraineeForm")
	public String retrieveTraineeForm(Model model)
	{
		
		//model.addAttribute("trainee", new Trainee());
		Trainee trainee3=null;
	    k++;
		if(k==2)
		{
			trainee3=new Trainee();
		trainee3.setTid(10);
		trainee3.setTraineeDomain("asdasd");
		trainee3.setTraineeLocation("dsd");
		trainee3.setTraineeName("dasd");
		}
		model.addAttribute("num",i);
		model.addAttribute("trainee",trainee3);
		return "retrieveTraineeForm";
	}
	
	@RequestMapping(value="/getRetrieveTrainee")
	public String getRetrieveTrainee(Model model,@RequestParam("tid") int tid)
	{
		
		model.addAttribute("tid",tid);
		return "redirect:/retrieveTraineeForm.obj";
		
	}
	
}
