package com.cg.spring.dao;

import java.util.List;

import com.cg.spring.entities.Trainee;

public interface ITraineeDao {

	public abstract Trainee addTrainee(Trainee trainee);
	public abstract Trainee removeTrainee(int tid);
	public abstract Trainee getTraineeDetails(int tid);
	public abstract List<Trainee> getAllTrainee();
	public abstract Trainee updateTrainee(Trainee trainee);
	
}
