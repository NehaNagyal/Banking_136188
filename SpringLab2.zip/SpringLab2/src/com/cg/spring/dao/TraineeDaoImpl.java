package com.cg.spring.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.spring.entities.Trainee;
@Repository
public class TraineeDaoImpl implements ITraineeDao {
	
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public Trainee addTrainee(Trainee trainee) {
	
		
		//System.out.println(trainee);
		entityManager.persist(trainee);
		
		return trainee;
	}

	@Override
	public Trainee removeTrainee(int tid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Trainee getTraineeDetails(int tid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Trainee> getAllTrainee() {
		TypedQuery<Trainee> query=entityManager.createQuery("Select t from Trainee t",Trainee.class);
		
		return query.getResultList();
	}

	@Override
	public Trainee updateTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		return null;
	}

}
