package com.cg.spring.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="trainee")
public class Trainee implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 6922497041377113865L;

	@Id
	@Column(name="tid")
	int tid;
	
	@Column(name="tname")
	String traineeName;
	
	@Column(name="tdomain")
	String traineeDomain;
	
	@Column(name="tlocation")
	String traineeLocation;

	public int getTid() {
		return tid;
	}

	public void setTid(int tid) {
		this.tid = tid;
	}

	public String getTraineeName() {
		return traineeName;
	}

	public void setTraineeName(String traineeName) {
		this.traineeName = traineeName;
	}

	public String getTraineeDomain() {
		return traineeDomain;
	}

	public void setTraineeDomain(String traineeDomain) {
		this.traineeDomain = traineeDomain;
	}

	public String getTraineeLocation() {
		return traineeLocation;
	}

	public void setTraineeLocation(String traineeLocation) {
		this.traineeLocation = traineeLocation;
	}

	@Override
	public String toString() {
		return "Trainee [tid=" + tid + ", traineeName=" + traineeName
				+ ", traineeDomain=" + traineeDomain + ", traineeLocation="
				+ traineeLocation + "]";
	}
	
	
	

	
}
