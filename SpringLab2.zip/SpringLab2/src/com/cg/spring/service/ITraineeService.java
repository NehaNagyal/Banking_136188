package com.cg.spring.service;

import java.util.List;

import com.cg.spring.entities.Trainee;

public interface ITraineeService {
	
	public abstract Trainee addTrainee(Trainee trainee);
	public abstract Trainee removeTrainee(Trainee trainee);
	public abstract Trainee getTraineeDetails(int tid);
	public abstract List<Trainee> getAllTrainee();
	public abstract Trainee updateTrainee(Trainee trainee);

}
