package com.cg.spring.service;

import java.util.List;



import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.cg.spring.dao.ITraineeDao;
import com.cg.spring.dao.TraineeDaoImpl;
import com.cg.spring.entities.Trainee;
@Service
@Transactional
public class TraineeServiceImpl implements ITraineeService {

	ITraineeDao traineeDao=new TraineeDaoImpl();
	@Override
	public Trainee addTrainee(Trainee trainee) {
		
		return traineeDao.addTrainee(trainee);
	}

	@Override
	public Trainee removeTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Trainee getTraineeDetails(int tid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Trainee> getAllTrainee() {
		// TODO Auto-generated method stub
		return traineeDao.getAllTrainee();
	}

	@Override
	public Trainee updateTrainee(Trainee trainee) {
		// TODO Auto-generated method stub
		return null;
	}

}
