package com.capgemini.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.jms.Session;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.dto.AccountDTO;
import com.capgemini.dto.TransactionDTO;
import com.capgemini.exception.BankException;
import com.capgemini.service.BankServiceImpl;
import com.capgemini.service.IBankService;

@Controller
public class BankController{

	@Autowired
	IBankService bankService;
	
	@RequestMapping(value="/accountinfo.htm",method=RequestMethod.POST)
	public String accountInfo(Model model,@RequestParam("customerName") String customerName)
	{
		List<AccountDTO> accList=bankService.displayAccountDetails(customerName);
		model.addAttribute("accountList", accList);
		return "accountinfo";
	}
}
