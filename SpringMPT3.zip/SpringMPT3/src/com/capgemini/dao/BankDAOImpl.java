package com.capgemini.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;










import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.capgemini.dto.AccountDTO;
import com.capgemini.dto.TransactionDTO;
import com.capgemini.exception.BankException;


@Repository
@Transactional
public class BankDAOImpl implements IBankDAO {
	
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public boolean validateCustomerName(String customerName) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<AccountDTO> displayAccountDetails(String customerName) {
		
		String qry="select accountDTO from AccountDTO accountDTO where accountDTO.customerName=:pCustomerName";
		
		TypedQuery<AccountDTO> query=entityManager.createQuery(qry,AccountDTO.class);
		query.setParameter("pCustomerName", customerName);
		List<AccountDTO> accList=query.getResultList();
		return accList;
	}

	@Override
	public int insertTransactionDetails(TransactionDTO transactionDTO) {
		// TODO Auto-generated method stub
		return 0;
	}


}
