package com.capgemini.dao;

import java.util.List;

import com.capgemini.dto.AccountDTO;
import com.capgemini.dto.TransactionDTO;
import com.capgemini.exception.BankException;

public interface IBankDAO {
	
	boolean validateCustomerName(String customerName);
	List<AccountDTO> displayAccountDetails(String customerName);
	int insertTransactionDetails(TransactionDTO transactionDTO);

}
