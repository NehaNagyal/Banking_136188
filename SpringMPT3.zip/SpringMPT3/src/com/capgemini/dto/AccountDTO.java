package com.capgemini.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity(name="account_details")
public class AccountDTO {
	@Id
	@Column(name="account_number")
	private String accountNumber;
	@Column(name="customer_name")
	private String  customerName;
	@Column(name="account_type")
	private String accountType;
	@Column(name="account_location")
	private String accountLocation;
	@Column(name="balance")
	private float balance;
	
	public AccountDTO(String accountNumber, String customerName,
			String accountType, String accountLocation, float balance) {
		super();
		this.accountNumber = accountNumber;
		this.customerName = customerName;
		this.accountType = accountType;
		this.accountLocation = accountLocation;
		this.balance = balance;
	}
	public AccountDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getAccountLocation() {
		return accountLocation;
	}
	public void setAccountLocation(String accountLocation) {
		this.accountLocation = accountLocation;
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) {
		this.balance = balance;
	}
	@Override
	public String toString() {
		return "AccountDTO [accountNumber=" + accountNumber + ", customerName="
				+ customerName + ", accountType=" + accountType
				+ ", accountLocation=" + accountLocation + ", balance="
				+ balance + "]";
	}
	

	
}
