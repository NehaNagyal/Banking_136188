package com.capgemini.dto;

import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name="transaction_details")
public class TransactionDTO {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="transaction_id")
	private int tranID;
	@Column(name="transaction_description")
	private String tranDesc;
	@Column(name="transaction_amount")
	private float tranAmount;
	@Column(name="transaction_date")
	private LocalDate tranDate;
	@Column(name="account_number")
	private String tranNumber;
	
	
	public TransactionDTO() {
		super();
		
	}


	public TransactionDTO(int tranID, String tranDesc, float tranAmount,
			LocalDate tranDate, String tranNumber) {
		super();
		this.tranID = tranID;
		this.tranDesc = tranDesc;
		this.tranAmount = tranAmount;
		this.tranDate = tranDate;
		this.tranNumber = tranNumber;
	}


	public int getTranID() {
		return tranID;
	}


	public void setTranID(int tranID) {
		this.tranID = tranID;
	}


	public String getTranDesc() {
		return tranDesc;
	}


	public void setTranDesc(String tranDesc) {
		this.tranDesc = tranDesc;
	}


	public float getTranAmount() {
		return tranAmount;
	}


	public void setTranAmount(float tranAmount) {
		this.tranAmount = tranAmount;
	}


	public LocalDate getTranDate() {
		return tranDate;
	}


	public void setTranDate(LocalDate tranDate) {
		this.tranDate = tranDate;
	}


	public String getTranNumber() {
		return tranNumber;
	}


	public void setTranNumber(String tranNumber) {
		this.tranNumber = tranNumber;
	}


	@Override
	public String toString() {
		return "TransactionDTO [tranID=" + tranID + ", tranDesc=" + tranDesc
				+ ", tranAmount=" + tranAmount + ", tranDate=" + tranDate
				+ ", tranNumber=" + tranNumber + "]";
	}
	
	
	
	
}
