package com.capgemini.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.dao.BankDAOImpl;
import com.capgemini.dao.IBankDAO;
import com.capgemini.dto.AccountDTO;
import com.capgemini.dto.TransactionDTO;
import com.capgemini.exception.BankException;

@Service
public class BankServiceImpl implements IBankService {
	
	@Autowired
	IBankDAO bankDAO;

	public BankServiceImpl() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean validateCustomerName(String customerName)
			throws BankException {
		
		return bankDAO.validateCustomerName(customerName);
	}

	@Override
	public List<AccountDTO> displayAccountDetails(String customerName){
		return bankDAO.displayAccountDetails(customerName);
	}

	/*
	 * Validating debit amount if debit amount is less than or equals to zero 
	 * and return the boolean value accordingly
	 * 
	 */
	@Override
	public boolean validateDebitAmount(float debitAmount) {
		if(debitAmount<=0)
		return false;
		else
			return true;
	}

	@Override
	public int insertTransactionDetails(TransactionDTO transactionDTO)
			throws BankException {
		
		return bankDAO.insertTransactionDetails(transactionDTO);
	}

}
