package com.capgemini.service;

import java.util.List;

import com.capgemini.dto.AccountDTO;
import com.capgemini.dto.TransactionDTO;
import com.capgemini.exception.BankException;

public interface IBankService {
	
	boolean validateCustomerName(String customerName) throws BankException;
	List<AccountDTO> displayAccountDetails(String customerName);
	boolean validateDebitAmount(float debitAmount);
	int insertTransactionDetails(TransactionDTO transactionDTO) throws BankException;

}
